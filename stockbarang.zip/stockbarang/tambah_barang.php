<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Barang</title>
    <link href="css/styles.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body class="sb-nav-fixed">
    <!-- Navigation bar -->
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand" href="index.php">
            <img src="assets\img\logo.png" alt="UMM HOSPITAL Logo" width="200" height="50">
        </a>
        <button class="btn btn-link btn-sm order-1 order-lg-0" id="sidebarToggle" href="#"><i class="fas fa-bars"></i></button>
    </nav>

    <!-- Sidebar -->
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <!-- Sidebar content -->
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid">
                    <!-- Form pencarian -->
                    <h1 class="mt-4">Stock Barang</h1>
                    <form action="search.php" method="GET" class="mb-4">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Cari barang..." name="keyword">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
                            </div>
                        </div>
                    </form>

                    <!-- Tombol Tambah Barang -->
                    <div class="row">
                        <div class="col-sm-12 col-md-6">
                            <h1 class="mt-4">Stock Barang</h1>
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <div class="container">
                                <div class="wrapper" style="padding:10px">
                                    <button id="btnTambahBarang" class="btn-export" name="export">
                                        <i class='fas fa-file-export' style='position:relative; right:5px; font-size:15px; color:#4F709C'></i>
                                        Export
                                    </button> 
                                </div>
                                <div class="wrapper">
                                    <button id="btnTambahBarang" class="btn-add" name="export">
                                        <i class='fa fa-plus-square' style='position:relative; right:8px; font-size:13px; color:white'></i>
                                        Tambah Barang
                                    </button> 
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Tabel data -->
                    <div class="card mb-4">
                        <div class="card-body">
                            <!-- Table content -->
                        </div>
                    </div>
                </div>
            </main>
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; Your Website 2020</div>
                        <div>
                            <a href="#">Privacy Policy</a>
                            &middot;
                            <a href="#">Terms &amp; Conditions</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="assets/demo/chart-area-demo.js"></script>
    <script src="assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
    <script src="assets/demo/datatables-demo.js"></script>

    <!-- JavaScript untuk tombol Tambah Barang -->
    <script>
        // Temukan tombol "Tambah Barang" berdasarkan id
        var btnTambahBarang = document.getElementById('btnTambahBarang');

        // Tambahkan event listener untuk menangani klik tombol
        btnTambahBarang.addEventListener('click', function() {
            // Di sini Anda dapat menentukan tindakan yang ingin dilakukan ketika tombol diklik
            // Contohnya, arahkan pengguna ke halaman tambah barang
            window.location.href = 'tambah_barang.php'; // Ganti 'tambah_barang.php' dengan halaman tambah barang yang sesuai
        });
    </script>
    <!-- JavaScript untuk tombol Tambah Barang -->
<script>
    // Temukan tombol "Tambah Barang" berdasarkan id
    var btnTambahBarang = document.getElementById('btnTambahBarang');

    // Tambahkan event listener untuk menangani klik tombol
    btnTambahBarang.addEventListener('click', function() {
        // Di sini Anda dapat menentukan tindakan yang ingin dilakukan ketika tombol diklik
        // Contohnya, arahkan pengguna ke halaman tambah barang
        window.location.href = 'tambah_barang.php'; // Ganti 'tambah_barang.php' dengan halaman tambah barang yang sesuai
    });
</script>

</body>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Head content di sini -->
</head>
<body class="sb-nav-fixed">
    <!-- Semua konten HTML Anda di sini -->

    <!-- Bagian bawah halaman -->
    <!-- JavaScript untuk tombol Tambah Barang -->
    <script>
        // Temukan tombol "Tambah Barang" berdasarkan id
        var btnTambahBarang = document.getElementById('btnTambahBarang');

        // Tambahkan event listener untuk menangani klik tombol
        btnTambahBarang.addEventListener('click', function() {
            // Di sini Anda dapat menentukan tindakan yang ingin dilakukan ketika tombol diklik
            // Contohnya, arahkan pengguna ke halaman tambah barang
            window.location.href = 'tambah_barang.php'; // Ganti 'tambah_barang.php' dengan halaman tambah barang yang sesuai
        });
    </script>
</body>
</html>

</html>
