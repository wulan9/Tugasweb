<?php
require 'function.php';
require 'cek.php';

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

if(isset($_GET['keyword'])) {
    $keyword = $_GET['keyword'];

    // Query untuk mencari data berdasarkan keyword
    $sql = "SELECT * FROM stock_barang WHERE nama_barang LIKE '%$keyword%'";
    $result = mysqli_query($conn, $sql);
} else {
    // Jika tidak ada keyword yang diberikan, tampilkan semua data
    $sql = "SELECT * FROM stock_barang";
    $result = mysqli_query($conn, $sql);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Atur meta dan judul -->
</head>
<body>
    <!-- Atur navigasi dan konten -->
    <h1>Hasil Pencarian</h1>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <!-- Sisipkan kolom lain yang diperlukan -->
            </tr>
        </thead>
        <tbody>
            <?php
            if (mysqli_num_rows($result) > 0) {
                $no = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $no++ . "</td>";
                    echo "<td>" . $row['nama_barang'] . "</td>";
                    // Sisipkan data kolom lain yang diperlukan
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='2'>Tidak ada data ditemukan</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>
