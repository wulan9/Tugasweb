<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Barang</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <?php
    if(isset($_GET['id'])) {
        $id_barang = $_GET['id'];
        echo "ID barang: " . $id_barang;
    } else {
        echo "Parameter 'id' tidak ditemukan dalam URL.";
    }
    ?>

    <div class="container mt-5">
        <h2>Edit Barang</h2>
        <?php
        // Cek apakah ID barang telah diteruskan melalui parameter URL
        if (isset($_GET['id'])) {
            // Lakukan koneksi ke database

            $conn = mysqli_connect("localhost","root","","dbrsumm");

            // Periksa koneksi
            if ($conn->connect_error) {
                die("Koneksi gagal: " . $conn->connect_error);
            }

            // Query untuk mendapatkan data barang berdasarkan ID
            $id_barang = $_GET['id'];
            $sql = "SELECT * FROM stock_barang WHERE id_barang = $id_barang";
            $result = $conn->query($sql);

            // Periksa apakah data ditemukan
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                // Form untuk mengedit data barang
                ?>
                <form action="proses_edit_hapus_barang.php" method="POST">
                <input type="hidden" name="modul" value="edit"> <!-- Tambahkan input tersembunyi untuk menandakan modul edit -->
                <input type="hidden" name="id_barang" value="<?php echo $row['id_barang']; ?>">
                <div class="form-group">
                    <label for="nama_barang">Nama Barang:</label>
                    <input type="text" class="form-control" id="nama_barang" name="nama_barang" value="<?php echo $row['nama_barang']; ?>">
                </div>
                <div class="form-group">
                    <label for="harga_beli">Harga Beli:</label>
                    <input type="text" class="form-control" id="harga_beli" name="harga_beli" value="<?php echo $row['harga_beli']; ?>">
                </div>
                <!-- Tambahkan kolom lain sesuai kebutuhan -->
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            </form>

                <?php
            } else {
                echo "Data barang tidak ditemukan.";
            }

            // Tutup koneksi
            $conn->close();
        } else {
            echo "ppp.";
        }
        ?>
    </div>
</body>
</html>
