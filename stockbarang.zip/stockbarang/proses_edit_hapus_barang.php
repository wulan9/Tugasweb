<?php
echo "ID barang: " . $id_barang;

require 'function.php';
require 'cek.php';

if(isset($_GET['modul']) && isset($_GET['id'])) {
    $id_barang = $_GET['id'];

    if($_GET['modul'] == 'edit') {
        // Lakukan proses edit data barang
        if(isset($_POST['nama_barang']) && isset($_POST['harga_beli'])) {
            $nama_barang = $_POST['nama_barang'];
            $harga_beli = $_POST['harga_beli'];

            // Query untuk update data barang
            $sql = "UPDATE stock_barang SET nama_barang='$nama_barang', harga_beli='$harga_beli' WHERE id_barang=$id_barang";

            if ($conn->query($sql) === TRUE) {
                echo "Data barang berhasil diperbarui.";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "Data tidak lengkap.";
        }
        
    } elseif($_GET['modul'] == 'hapus') {
        // Lakukan proses hapus data barang
        // Query untuk hapus data barang
        $sql = "DELETE FROM stock_barang WHERE id_barang=$id_barang";

        if ($conn->query($sql) === TRUE) {
            echo "Data barang berhasil dihapus.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Modul tidak valid";
    }
} else {
    echo "ID barang tidak ditemukan.";
}
?>
